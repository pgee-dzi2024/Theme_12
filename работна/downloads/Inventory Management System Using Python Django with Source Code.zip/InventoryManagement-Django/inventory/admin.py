from django.contrib import admin
from .models import Stock

admin.site.register(Stock)